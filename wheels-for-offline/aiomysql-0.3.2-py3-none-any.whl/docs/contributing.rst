.. _aiomysql-contributing:

.. include:: ../CONTRIBUTING.rst
